@include('layouts.header')

<div class="min-h-screen flex items-center justify-center">
  <h2 class="text-white text-2xl">Dashboard</h2>
  </div>
      
</body>
</html>

