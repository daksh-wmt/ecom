<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="min-h-screen flex items-center justify-center">
  <h2 class="text-white text-2xl">Dashboard</h2>
  </div>
      
</body>
</html>

<?php /**PATH /home/wmt/Daksh/laravel/github/ecom/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>