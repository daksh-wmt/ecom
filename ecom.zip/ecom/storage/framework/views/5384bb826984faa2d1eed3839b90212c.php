<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(session('success')): ?>
<div class="bg-green-500 text-white px-4 py-2 mb-4">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>
    <div class=" bg-slate-900 min-h-screen flex items-center justify-center">
        <div class="max-w-md w-full p-6 bg-black rounded-lg shadow-lg">

            <h1 class="text-2xl text-white font-semibold mb-6">Add Category</h1>
            <form method="post" action="<?php echo e(route('admin.addcategory')); ?>" id="form">
                <?php echo csrf_field(); ?>
    
                <div class="mb-4">
                    <label for="category_name" class="block text-white font-bold mb-2">Category Name:</label>
                    <input type="text" id="category_name" name="category_name"
                        class="w-full px-3 py-2 border rounded shadow-md focus:outline-none focus:ring focus:border-blue-300 bg-slate-300">
                    <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="mt-2 mb-4 text-red-700"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
    
                <div class="mb-4">
                    <label for="parent_category_id" class="block text-white font-bold mb-2">Parent Category:</label>
                    
                    <select name="parent_category_id" id="parent_category_id" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                        <option value="" selected>Select Parent Category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
    
                <?php if($errors->has('login_error')): ?>
                    <div class="mt-2 mb-4 text-red-700">
                        <?php echo e($errors->first('login_error')); ?>

                    </div>
                <?php endif; ?>
    
                <div class="mb-4">
                    <input type="submit" value="submit" id="loginbutton"
                        class="bg-orange-700 text-white py-2 w-full rounded hover:bg-orange-800 cursor-pointer mt-2">
                </div>
            </form>
        </div>
    
    </div>

    
      
</body>
</html>

<?php /**PATH /home/wmt/Daksh/laravel/github/ecom/resources/views/admin/add_category.blade.php ENDPATH**/ ?>