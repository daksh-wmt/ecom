<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if(session('success')): ?>
<div class="bg-green-500 text-white px-4 py-2 mb-4">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>
<!-- component -->
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdn.tailgrids.com/tailgrids-fallback.css" />
<script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>

<!-- ====== Table Section Start -->
<section class="bg-slate-900 px-10 py-10 pl-10 pr-10">
    <div class="container">
        <div class="flex flex-wrap -mx-4">
            <div class="w-full px-4">
                <div class="max-w-full overflow-x-auto">
                    <table class="table-auto w-full">
                        <thead>
                            <tr class="bg-orange-700 text-center">
                                <th
                                    class="
                           w-1/6
                           min-w-[160px]
                           text-lg
                           font-semibold
                           text-white
                           py-4
                           lg:py-7
                           px-3
                           lg:px-4
                           border-l border-transparent
                           ">
                                    Product
                                </th>
                                <th
                                    class="
                           w-1/6
                           min-w-[160px]
                           text-lg
                           font-semibold
                           text-white
                           py-4
                           lg:py-7
                           px-3
                           lg:px-4
                           ">
                                    Category
                                </th>
                                <th
                                    class="
                           w-1/6
                           min-w-[160px]
                           text-lg
                           font-semibold
                           text-white
                           py-4
                           lg:py-7
                           px-3
                           lg:px-4
                           ">
                                    Basic Price
                                </th>
                                <th
                                    class="
                           w-1/6
                           min-w-[160px]
                           text-lg
                           font-semibold
                           text-white
                           py-4
                           lg:py-7
                           px-3
                           lg:px-4
                           ">
                                    Discounted Price
                                </th>
                                <th
                                    class="
                           w-1/6
                           min-w-[160px]
                           text-lg
                           font-semibold
                           text-white
                           py-4
                           lg:py-7
                           px-3
                           lg:px-4
                           ">
                                    Small Description
                                </th>
                                <th
                                    class="
                           w-1/6
                           min-w-[160px]
                           text-lg
                           font-semibold
                           text-white
                           py-4
                           lg:py-7
                           px-3
                           lg:px-4
                           border-r border-transparent
                           ">
                                    Detail  Description
                                </th>
                                <th
                                    class="
                        w-1/6
                        min-w-[160px]
                        text-lg
                        font-semibold
                        text-white
                        py-4
                        lg:py-7
                        px-3
                        lg:px-4
                        border-r border-transparent
                        ">
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="" id="productRow<?php echo e($product->id); ?>">
                                    <td
                                        class="
                           text-center text-dark
                           font-medium
                           text-base
                           py-5
                           px-2
                           bg-[#F3F6FF]
                           border-b border-l border-[#E8E8E8]
                           ">

                                        <?php echo e($product->product_name); ?>



                                    </td>
                                    <td
                                        class="
                           text-center text-dark
                           font-medium
                           text-base
                           py-5
                           px-2
                           bg-white
                           border-b border-[#E8E8E8]
                           ">
                                        <?php echo e($product->category->category_name ?? ''); ?>

                                    </td>
                                    <td
                                        class="
                           text-center text-dark
                           font-medium
                           text-base
                           py-5
                           px-2
                           bg-[#F3F6FF]
                           border-b border-[#E8E8E8]
                           ">
                                        <?php echo e($product->basic_price); ?>

                                    </td>
                                    <td
                                        class="
                           text-center text-dark
                           font-medium
                           text-base
                           py-5
                           px-2
                           bg-white
                           border-b border-[#E8E8E8]
                           ">
                                        <?php echo e($product->discounted_price); ?>

                                    </td>
                                    <td
                                        class="
                           text-center text-dark
                           font-medium
                           text-base
                           py-5
                           px-2
                           bg-[#F3F6FF]
                           border-b border-[#E8E8E8]
                           ">
                                        <?php echo e($product->small_description); ?>

                                    </td>
                                    <td
                                        class="
                           text-center text-dark
                           font-medium
                           text-base
                           py-5
                           px-2
                           bg-white
                           border-b border-r border-[#E8E8E8]
                           ">
                                        <?php echo e($product->detail_description); ?>

                                    </td>
                                    <td
                                        class="
                           text-center text-dark
                           font-medium
                           text-base
                           py-5
                           px-2
                           bg-white
                           border-b border-r border-[#E8E8E8]
                           ">
                                        <a href="/admin/addproduct/<?php echo e($product->id); ?>"
                                            class="
                              border border-primary
                              py-2
                              px-6
                              text-primary
                              inline-block
                              rounded
                              hover:bg-primary hover:text-white
                              ">
                                            Edit
                                        </a>
                                        <a 
                                        href="#"
                                        onclick="deleteProduct(<?php echo e($product->id); ?>)"    
                                        id="deleteLink"
                                            class="
                              border border-primary
                              py-2
                              px-6
                              mt-2
                              text-primary
                              inline-block
                              rounded
                              hover:bg-red-600 hover:text-white
                              ">
                                            Delete
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ====== Table Section End -->

</body>

</html>






<script>
    function deleteProduct(productId) {
        if (confirm('Are you sure you want to delete this product?')) {
            var url = '/admin/delete/' + productId;

            fetch(url, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    'Content-Type': 'application/json',
                },
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                // Handle success
                alert(data.message);

                // Remove the product row from the table
                var productRow = document.getElementById('productRow' + productId);
                if (productRow) {
                    productRow.remove();
                }
                
            })
            .catch(error => {
                // Handle errors here
                console.error('There was a problem with the fetch operation:', error);
            });
        }
    }
</script>
<?php /**PATH /home/wmt/Daksh/laravel/github/ecom/resources/views/admin/view_product.blade.php ENDPATH**/ ?>